<?php
    $error = false;
    $jwt = false;
    include 'Controllers/sso.php';

    include 'Views/sso.php';
