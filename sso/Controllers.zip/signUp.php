<?php
    $error = false;
    include 'Controllers/signUp.php';
    include 'Views/signUp.php';
