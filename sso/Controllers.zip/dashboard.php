<?php
    $error = false;
    $key = "myKey";
    include 'Controllers/dashboard.php';
    include 'Views/dashboard.php';
